this doc is associated with a diagram for musheer AI

the only purpose of this file is to explain diagram that made without knowing what's inside the system so it's a black-box diagram. I will use writing by services to organize this doc easily 

# Introduction
after user logs in, user will be handed an interface full of services which are:
- Chat 
- Review Multiple contracts
- Command Guides
- Special sources
- Legal radars
- Task Management
- Comparing documents
- Documents management

# Chat with Musheer
user shown a text box and with media and documents insertion.
Once a user sends their prompt, prompt goes to musheer system, musheer generate the response and gets information needed for that response, finally response sent back to user 

- Steps:
	1. user sends prompt
	2. musheer retrieves required data from database
	3. Musheer generates response
	4. system sends back the response to user
	5. user finally handed the response 


# Review multiple contracts

- user shown a list of pre-made contracts templates, each template has a logic that takes a specific type of legal document (specialty based on template needs), and scrapes out what's in doc content and places it in the applicable columns that are made before
  
- User can make another custom template 

Steps (Using templates scenario):
1. user shown a list of pre-made contract templates
2. user clicks one of templates
3. user insert their document (document should be specialized for used template)
4. request goes to Musheer system
5. musheer extracts all applicable data for that template
6. musheer puts these data into their applicable columns and rows 
7. system returns table result to user 

steps (managing templates scenario):
1. user shown a list of pre-made contract templates + with a "new review"
2. user goes to it and start editing their new custom template
3. user saves and submit their template 
4. system saves their work


# Legal radar
 nothing appears in this service, couldn't understand anything from it 
 but appears to me it tries to fetch something from an external source

# Documents Management
this service takes two documents and 

steps:
1. user insert two legal documents 
2. user selects the purpose of shown services which are 
	1. rate differences between given files (should be old and new version of the same file)
	2. spot legal missing details and structural differences
	3. compare legal between legal specialization
3. user sends files and service needed 
4. Musheer receives files and do what service selected asked for 
5. musheer returns back response
6. user receives reponse

# special sources 


# Command guides

# Task Management

# Documents comparing
