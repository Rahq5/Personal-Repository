my goal here to revise all of Shoura RAG system services 

# Services
## Review of multiple contracts
provides pre-made contracts templates

what it can do:
- use pre-made templates for sort of things like contracts
- make new templates 
- templates for contracts as example, you put the file and when u hit play it extracts all informations according to existing colmuns 

> Notes: i have doubts that they made our intern files using shoura, using this service exactly


## legal Radar
looks like it shows all legal updates

couldnt explore it was stuck at loading new updates


## comparing Docs
it's a great service that compares the difference between two files , let's say you got two employment offers, this service would help showing job details differences like salary, yearly income, vacations , etc... .

it has two types of what am gonna call it "comapring methods" which is:

- table comparing: shows diffirences in the same topic type by getting the actual text from both docs and adding some explaintory details /

- comparing report: works diffirently , shows 5 elements (subject A, Subject B, category, importance, reliability)
  
	- importancy: shows a percentage scaling of conflicting between two files (like mentioned here in my intern that it should end in 2026\4 while in the company's file it shows it ends in 2025\4 which is a wrong date and causes a critical conflict) so it's more into the impact of this conflictions
	  
	- category: shows what type of problem mentioned , like data in university file shows name,date,ID while in company's shows only name. category in his case is "identification data omission"
	  
	- reliability: didnt catch the point of this 
	  
	- More Details: shows more details and reasons of as example high importancy and "why" it's high 


## command guides
Instead of performing a open-ended search, the system evaluates your uploaded file against defined **Rules**, checking for compliance, acceptable criteria, unacceptable conditions , and alternative negotiation positions.


## Special Sources 
no content

## Task management
managing tasks and asginee in multiple categories, (new, working, done) also an ability to add more lists , each task creation has:
- type service
- task title
- asginee
- project name 
- client name
- start - end date and time
- work time (written in hours only)
- task missions
- docs 

## Managing Docs
none (says coming soon)