# Intern Assignment: Saudi Legal Document Crawler

## Objective

Build a crawler that collects publicly available Saudi legal documents from official `.sa` government sources, downloads them as PDFs, and organizes them into a clean, labeled corpus for our model training work.

## Authorized Sources

Collect only from these (and equivalent official `.sa` government bodies):

- `laws.boe.gov.sa` **/** `boe.gov.sa` — Bureau of Experts at the Council of Ministers: laws, regulations, royal decrees, Council of Ministers resolutions
- `uqn.gov.sa` — Umm Al-Qura official gazette (authoritative primary source)
- `moj.gov.sa` — Ministry of Justice: circulars, monthly reports, published judgment collections
- `my.gov.sa/ar/rules` — National Platform, cross-ministry regulations
- **Sector regulators as needed** — e.g. `sama.gov.sa`, `zatca.gov.sa`, `sfda.gov.sa`, `cma.org.sa`

## Expanding the Corpus

You may collect additional documents relevant to our domain, provided every source is one of:

- (a) published openly by an official `.sa` government body,
- (b) under an explicit open license (e.g. Creative Commons, public domain), or
- (c) data we have written permission or a license to use.

For each new source, document the URL, the terms of use, and why it's permitted **before** collecting. Anything behind a login, paywall, or another company's platform — including competitor legal databases — is out of scope. When in doubt, flag for review.

## Tasks

1. **Survey each source.** Map URL structure, pagination, and how PDFs are linked.
2. **Build the crawler.** Python (`requests` + `BeautifulSoup`, or `scrapy`). Apply the engineering standards above.
3. **Download PDFs.** Deduplicate by content hash.
4. **Organize the corpus:**
   - Path layout: `corpus/{category}/{source}/{doc_id}.pdf`
   - `metadata.csv` columns: title, document number, hijri date, gregorian date, source URL, retrieval date, category, license note
5. **Categories:** `regulations`, `royal_decrees`, `circulars`, `gazette`, `judgments`.
6. **Write a README.** Document sources covered, what was collected, and any licensing flags raised.

## Deliverables

- Crawler repository (with setup/run instructions)
- Organized corpus directory
- `metadata.csv`
- `README.md`
- A one-page note on coverage: which categories are well-covered vs. sparse. (Expect judicial precedents and legal books/research to be sparse — that's a known gap, not a failure.)

## Notes for Context

The laws/regulations/circulars/gazette categories are well served by open official portals. Judicial precedents and legal research/books are the hard part — comprehensive open collections of those largely don't exist, which is why commercial platforms charge for them. Don't burn time trying to reconstruct a proprietary collection; collect what's openly available and flag the gaps.